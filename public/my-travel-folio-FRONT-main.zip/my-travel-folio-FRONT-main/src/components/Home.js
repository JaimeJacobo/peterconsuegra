import React from 'react'

const Home = (props)=>{
  return(
    <div>
      
      <h2>My Travel Folio</h2>

    </div>
  )
}

export default Home